const mongoose = require("mongoose")

const CarbonDataSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  bodyType: {
    type: String,
    enum: ["Slim", "Average", "Athletic", "Overweight"],
    required: true,
  },
  sex: {
    type: String,
    enum: ["Male", "Female", "Other"],
    required: true,
  },
  diet: {
    type: String,
    enum: ["Vegan", "Vegetarian", "Pescatarian", "Omnivore", "Heavy Meat Eater"],
    required: true,
  },
  howOftenShower: {
    type: String,
    enum: ["Daily", "Every other day", "Twice a week", "Once a week"],
    required: true,
  },
  heatingEnergySource: {
    type: String,
    enum: ["Electricity", "Natural Gas", "Oil", "Wood", "Coal", "None"],
    required: true,
  },
  transport: {
    type: String,
    enum: ["Walking/Cycling", "Public Transport", "Car", "Motorcycle"],
    required: true,
  },
  vehicleType: {
    type: String,
    enum: ["None", "Electric", "Hybrid", "Gasoline", "Diesel"],
    required: true,
  },
  socialActivity: {
    type: String,
    enum: ["Rarely", "Monthly", "Weekly", "Multiple times per week"],
    required: true,
  },
  monthlyGroceryBill: {
    type: Number,
    required: true,
  },
  frequencyOfTravelingByAir: {
    type: String,
    enum: ["Never", "Once a year", "2-3 times a year", "Monthly", "Weekly"],
    required: true,
  },
  vehicleMonthlyDistanceKm: {
    type: Number,
    required: true,
  },
  wasteBagSize: {
    type: String,
    enum: ["Small", "Medium", "Large"],
    required: true,
  },
  wasteBagWeeklyCount: {
    type: Number,
    required: true,
  },
  howLongTvPcDailyHour: {
    type: Number,
    required: true,
  },
  howManyNewClothesMonthly: {
    type: Number,
    required: true,
  },
  howLongInternetDailyHour: {
    type: Number,
    required: true,
  },
  energyEfficiency: {
    type: String,
    enum: ["Yes", "No"],
    required: true,
  },
  recycling: {
    type: [String],
    enum: ["Paper", "Plastic", "Glass", "Metal", "Electronics", "None"],
    required: true,
  },
  cookingWith: {
    type: [String],
    enum: ["Electric Stove", "Gas Stove", "Microwave", "Oven", "Air Fryer"],
    required: true,
  },
  carbonEmission: {
    type: Number,
    default: 0,
  },
  date: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("CarbonData", CarbonDataSchema)
