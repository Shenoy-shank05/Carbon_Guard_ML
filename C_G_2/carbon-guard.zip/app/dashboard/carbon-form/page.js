"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Mic, MicOff, Send, Loader2 } from "lucide-react"
import { submitCarbonData } from "../../api/carbon"

export default function CarbonForm() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [error, setError] = useState("")
  const [formData, setFormData] = useState({
    bodyType: "",
    sex: "",
    diet: "",
    howOftenShower: "",
    heatingEnergySource: "",
    transport: "",
    vehicleType: "",
    socialActivity: "",
    monthlyGroceryBill: "",
    frequencyOfTravelingByAir: "",
    vehicleMonthlyDistanceKm: "",
    wasteBagSize: "",
    wasteBagWeeklyCount: "",
    howLongTvPcDailyHour: "",
    howManyNewClothesMonthly: "",
    howLongInternetDailyHour: "",
    energyEfficiency: "",
    recycling: [],
    cookingWith: [],
  })

  // Options for select fields
  const options = {
    bodyType: ["Slim", "Average", "Athletic", "Overweight"],
    sex: ["Male", "Female", "Other"],
    diet: ["Vegan", "Vegetarian", "Pescatarian", "Omnivore", "Heavy Meat Eater"],
    howOftenShower: ["Daily", "Every other day", "Twice a week", "Once a week"],
    heatingEnergySource: ["Electricity", "Natural Gas", "Oil", "Wood", "Coal", "None"],
    transport: ["Walking/Cycling", "Public Transport", "Car", "Motorcycle"],
    vehicleType: ["None", "Electric", "Hybrid", "Gasoline", "Diesel"],
    socialActivity: ["Rarely", "Monthly", "Weekly", "Multiple times per week"],
    frequencyOfTravelingByAir: ["Never", "Once a year", "2-3 times a year", "Monthly", "Weekly"],
    wasteBagSize: ["Small", "Medium", "Large"],
    energyEfficiency: ["Yes", "No"],
    recycling: ["Paper", "Plastic", "Glass", "Metal", "Electronics", "None"],
    cookingWith: ["Electric Stove", "Gas Stove", "Microwave", "Oven", "Air Fryer"],
  }

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target

    if (type === "checkbox") {
      if (checked) {
        setFormData({
          ...formData,
          [name]: [...(formData[name] || []), value],
        })
      } else {
        setFormData({
          ...formData,
          [name]: formData[name].filter((item) => item !== value),
        })
      }
    } else {
      setFormData({
        ...formData,
        [name]: value,
      })
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    try {
      // Convert string numbers to actual numbers
      const processedData = {
        ...formData,
        monthlyGroceryBill: Number(formData.monthlyGroceryBill),
        vehicleMonthlyDistanceKm: Number(formData.vehicleMonthlyDistanceKm),
        wasteBagWeeklyCount: Number(formData.wasteBagWeeklyCount),
        howLongTvPcDailyHour: Number(formData.howLongTvPcDailyHour),
        howManyNewClothesMonthly: Number(formData.howManyNewClothesMonthly),
        howLongInternetDailyHour: Number(formData.howLongInternetDailyHour),
      }

      // Submit data to API
      await submitCarbonData(processedData)

      // Redirect to insights page
      router.push("/dashboard/insights")
    } catch (err) {
      console.error("Error submitting form:", err)
      setError(err.message || "There was an error submitting your data. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Voice assistant functionality
  const startListening = () => {
    if (!("webkitSpeechRecognition" in window)) {
      alert("Your browser doesn't support speech recognition. Try using Chrome.")
      return
    }

    const recognition = new window.webkitSpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true

    recognition.onstart = () => {
      setIsListening(true)
      setTranscript("Listening...")
    }

    recognition.onresult = (event) => {
      let interimTranscript = ""
      let finalTranscript = ""

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript
        } else {
          interimTranscript += event.results[i][0].transcript
        }
      }

      setTranscript(finalTranscript || interimTranscript)

      // Simple voice commands processing
      processVoiceCommand(finalTranscript)
    }

    recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error)
      setIsListening(false)
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognition.start()
    window.recognition = recognition
  }

  const stopListening = () => {
    if (window.recognition) {
      window.recognition.stop()
      setIsListening(false)
    }
  }

  const processVoiceCommand = (command) => {
    // Very basic command processing for demo
    const lowerCommand = command.toLowerCase()

    // Example: "My diet is vegetarian"
    if (lowerCommand.includes("diet is")) {
      const dietOptions = options.diet.map((d) => d.toLowerCase())
      for (const diet of dietOptions) {
        if (lowerCommand.includes(diet)) {
          setFormData({
            ...formData,
            diet: diet.charAt(0).toUpperCase() + diet.slice(1),
          })
          break
        }
      }
    }

    // Example: "I travel by car"
    if (lowerCommand.includes("travel by") || lowerCommand.includes("transport is")) {
      const transportOptions = options.transport.map((t) => t.toLowerCase())
      for (const transport of transportOptions) {
        if (lowerCommand.includes(transport.toLowerCase())) {
          setFormData({
            ...formData,
            transport: transport.charAt(0).toUpperCase() + transport.slice(1),
          })
          break
        }
      }
    }

    // Example: "Submit the form"
    if (lowerCommand.includes("submit") || lowerCommand.includes("save")) {
      document.getElementById("carbon-form").dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }))
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Carbon Footprint Data Form</h1>
        <p className="text-gray-600">
          Please fill out this form to calculate your carbon footprint. You can also use the voice assistant to fill out
          the form.
        </p>
      </div>

      {error && <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">{error}</div>}

      {/* Voice assistant */}
      <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Voice Assistant</h2>
          <div>
            {isListening ? (
              <button onClick={stopListening} className="bg-red-100 text-red-600 p-2 rounded-full">
                <MicOff className="h-5 w-5" />
              </button>
            ) : (
              <button onClick={startListening} className="bg-emerald-100 text-emerald-600 p-2 rounded-full">
                <Mic className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        <div
          className={`p-4 rounded-lg ${isListening ? "bg-emerald-50 border border-emerald-200" : "bg-gray-50 border border-gray-200"}`}
        >
          <p className="text-sm text-gray-600 mb-2">
            {isListening ? "Listening... Speak now." : "Click the microphone to start speaking"}
          </p>
          <p className="font-medium">{transcript || "Try saying: 'My diet is vegetarian' or 'I travel by car'"}</p>
        </div>
      </div>

      {/* Carbon footprint form */}
      <form id="carbon-form" onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Personal Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Personal Information</h3>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Body Type</label>
              <select
                name="bodyType"
                value={formData.bodyType}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Body Type</option>
                {options.bodyType.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Sex</label>
              <select
                name="sex"
                value={formData.sex}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Sex</option>
                {options.sex.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Diet</label>
              <select
                name="diet"
                value={formData.diet}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Diet</option>
                {options.diet.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">How Often Do You Shower?</label>
              <select
                name="howOftenShower"
                value={formData.howOftenShower}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Frequency</option>
                {options.howOftenShower.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Home Energy */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Home Energy</h3>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Heating Energy Source</label>
              <select
                name="heatingEnergySource"
                value={formData.heatingEnergySource}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Energy Source</option>
                {options.heatingEnergySource.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Do You Care About Energy Efficiency?
              </label>
              <select
                name="energyEfficiency"
                value={formData.energyEfficiency}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Option</option>
                {options.energyEfficiency.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Cooking With (Select at least one)</label>
              <div className="grid grid-cols-2 gap-2">
                {options.cookingWith.map((option) => (
                  <label key={option} className="flex items-center">
                    <input
                      type="checkbox"
                      name="cookingWith"
                      value={option}
                      checked={formData.cookingWith?.includes(option) || false}
                      onChange={handleInputChange}
                      className="mr-2"
                    />
                    {option}
                  </label>
                ))}
              </div>
              {formData.cookingWith.length === 0 && (
                <p className="text-xs text-red-500 mt-1">Please select at least one cooking method</p>
              )}
            </div>
          </div>

          {/* Transportation */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Transportation</h3>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Primary Transport Method</label>
              <select
                name="transport"
                value={formData.transport}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Transport Method</option>
                {options.transport.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Type</label>
              <select
                name="vehicleType"
                value={formData.vehicleType}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Vehicle Type</option>
                {options.vehicleType.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Monthly Distance Traveled by Vehicle (km)
              </label>
              <input
                type="number"
                name="vehicleMonthlyDistanceKm"
                value={formData.vehicleMonthlyDistanceKm}
                onChange={handleInputChange}
                placeholder="e.g., 500"
                className="w-full p-2 border border-gray-300 rounded-md"
                required
                min="0"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Frequency of Air Travel</label>
              <select
                name="frequencyOfTravelingByAir"
                value={formData.frequencyOfTravelingByAir}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Frequency</option>
                {options.frequencyOfTravelingByAir.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Lifestyle */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Lifestyle</h3>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Social Activity Frequency</label>
              <select
                name="socialActivity"
                value={formData.socialActivity}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">Select Frequency</option>
                {options.socialActivity.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Grocery Bill ($)</label>
              <input
                type="number"
                name="monthlyGroceryBill"
                value={formData.monthlyGroceryBill}
                onChange={handleInputChange}
                placeholder="e.g., 400"
                className="w-full p-2 border border-gray-300 rounded-md"
                required
                min="0"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Daily Hours on TV/PC</label>
              <input
                type="number"
                name="howLongTvPcDailyHour"
                value={formData.howLongTvPcDailyHour}
                onChange={handleInputChange}
                placeholder="e.g., 4"
                className="w-full p-2 border border-gray-300 rounded-md"
                required
                min="0"
                max="24"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Daily Hours on Internet</label>
              <input
                type="number"
                name="howLongInternetDailyHour"
                value={formData.howLongInternetDailyHour}
                onChange={handleInputChange}
                placeholder="e.g., 3"
                className="w-full p-2 border border-gray-300 rounded-md"
                required
                min="0"
                max="24"
              />
            </div>
          </div>

          {/* Consumption & Waste */}
          <div className="md:col-span-2">
            <h3 className="text-lg font-semibold mb-4">Consumption & Waste</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">New Clothes Purchased Monthly</label>
                  <input
                    type="number"
                    name="howManyNewClothesMonthly"
                    value={formData.howManyNewClothesMonthly}
                    onChange={handleInputChange}
                    placeholder="e.g., 2"
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                    min="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Waste Bag Size</label>
                  <select
                    name="wasteBagSize"
                    value={formData.wasteBagSize}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="">Select Size</option>
                    {options.wasteBagSize.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Waste Bags Per Week</label>
                  <input
                    type="number"
                    name="wasteBagWeeklyCount"
                    value={formData.wasteBagWeeklyCount}
                    onChange={handleInputChange}
                    placeholder="e.g., 2"
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                    min="0"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    What Do You Recycle? (Select all that apply)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {options.recycling.map((option) => (
                      <label key={option} className="flex items-center">
                        <input
                          type="checkbox"
                          name="recycling"
                          value={option}
                          checked={formData.recycling?.includes(option) || false}
                          onChange={handleInputChange}
                          className="mr-2"
                        />
                        {option}
                      </label>
                    ))}
                  </div>
                  {formData.recycling.length === 0 && (
                    <p className="text-xs text-red-500 mt-1">Please select at least one option (or 'None')</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting || formData.cookingWith.length === 0 || formData.recycling.length === 0}
            className="bg-emerald-600 text-white py-2 px-6 rounded-md hover:bg-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="animate-spin h-4 w-4 mr-2" />
                Calculating...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Calculate Carbon Footprint
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
