"use client"

import { useState, useEffect } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts"
import { ArrowDown, ArrowUp, Leaf, AlertTriangle, Info, FileInput } from "lucide-react"
import Link from "next/link"
import { getCarbonData, getLatestCarbonData } from "../../api/carbon"

export default function Insights() {
  const [userData, setUserData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get all carbon data for trends
        const allData = await getCarbonData()

        // Get latest data with insights
        const latestData = await getLatestCarbonData()

        // Process monthly trend data
        const monthlyTrend = processMonthlyTrend(allData)

        // Transform data for UI
        const transformedData = {
          carbonFootprint: {
            current: latestData.latestData?.carbonEmission || 0,
            previous: latestData.previousData?.carbonEmission || 0,
            change: latestData.changePercentage || 0,
            globalAverage: 16.3, // Static value for now
            countryAverage: 15.7, // Static value for now
          },
          breakdown: latestData.insights?.breakdown || [],
          monthlyTrend: monthlyTrend,
          recommendations: latestData.insights?.recommendations || [],
        }

        setUserData(transformedData)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load insights data. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  // Process monthly trend data from all submissions
  const processMonthlyTrend = (data) => {
    if (!data || data.length === 0) {
      // Return mock data if no real data available
      return [
        { month: "Jan", emission: 14.2 },
        { month: "Feb", emission: 13.8 },
        { month: "Mar", emission: 13.5 },
        { month: "Apr", emission: 13.1 },
        { month: "May", emission: 12.8 },
        { month: "Jun", emission: 12.5 },
      ]
    }

    // Sort data by date
    const sortedData = [...data].sort((a, b) => new Date(a.date) - new Date(b.date))

    // Group by month and year
    const monthlyData = {}
    sortedData.forEach((entry) => {
      const date = new Date(entry.date)
      const monthYear = `${date.getFullYear()}-${date.getMonth() + 1}`
      const monthName = date.toLocaleString("default", { month: "short" })

      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = {
          month: monthName,
          emission: entry.carbonEmission,
          count: 1,
        }
      } else {
        monthlyData[monthYear] = {
          month: monthName,
          emission:
            (monthlyData[monthYear].emission * monthlyData[monthYear].count + entry.carbonEmission) /
            (monthlyData[monthYear].count + 1),
          count: monthlyData[monthYear].count + 1,
        }
      }
    })

    // Convert to array and take last 6 months (or all if less than 6)
    const result = Object.values(monthlyData)
    return result.slice(-6)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">{error}</div>
        <Link
          href="/dashboard/carbon-form"
          className="bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-500 inline-flex items-center"
        >
          <FileInput className="h-4 w-4 mr-2" />
          Submit Your Carbon Data
        </Link>
      </div>
    )
  }

  // Calculate total carbon footprint
  const totalEmission = userData.breakdown.reduce((sum, item) => sum + item.value, 0)

  // Prepare data for pie chart
  const pieData = userData.breakdown.map((item) => ({
    name: item.name,
    value: item.value,
  }))

  // Colors for pie chart
  const COLORS = ["#16a34a", "#22c55e", "#4ade80", "#86efac", "#bbf7d0"]

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Carbon Footprint Insights</h1>
        <p className="text-gray-600">Detailed analysis of your environmental impact</p>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Your Carbon Footprint</h3>
          <div className="flex items-end">
            <span className="text-3xl font-bold">{userData.carbonFootprint.current}</span>
            <span className="text-gray-500 ml-1 mb-1">tons CO₂/year</span>
          </div>
          <div className="mt-2 flex items-center">
            <span
              className={`text-sm font-medium ${userData.carbonFootprint.change < 0 ? "text-green-600" : "text-red-600"}`}
            >
              {userData.carbonFootprint.change}%
            </span>
            {userData.carbonFootprint.change < 0 ? (
              <ArrowDown className="h-4 w-4 text-green-600 ml-1" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600 ml-1" />
            )}
            <span className="text-gray-500 text-sm ml-1">vs previous</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Global Average</h3>
          <div className="flex items-end">
            <span className="text-3xl font-bold">{userData.carbonFootprint.globalAverage}</span>
            <span className="text-gray-500 ml-1 mb-1">tons CO₂/year</span>
          </div>
          <div className="mt-2 flex items-center">
            <span
              className={`text-sm font-medium ${userData.carbonFootprint.current < userData.carbonFootprint.globalAverage ? "text-green-600" : "text-red-600"}`}
            >
              {(
                ((userData.carbonFootprint.current - userData.carbonFootprint.globalAverage) /
                  userData.carbonFootprint.globalAverage) *
                100
              ).toFixed(0)}
              %
            </span>
            {userData.carbonFootprint.current < userData.carbonFootprint.globalAverage ? (
              <ArrowDown className="h-4 w-4 text-green-600 ml-1" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600 ml-1" />
            )}
            <span className="text-gray-500 text-sm ml-1">your footprint</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Country Average</h3>
          <div className="flex items-end">
            <span className="text-3xl font-bold">{userData.carbonFootprint.countryAverage}</span>
            <span className="text-gray-500 ml-1 mb-1">tons CO₂/year</span>
          </div>
          <div className="mt-2 flex items-center">
            <span
              className={`text-sm font-medium ${userData.carbonFootprint.current < userData.carbonFootprint.countryAverage ? "text-green-600" : "text-red-600"}`}
            >
              {(
                ((userData.carbonFootprint.current - userData.carbonFootprint.countryAverage) /
                  userData.carbonFootprint.countryAverage) *
                100
              ).toFixed(0)}
              %
            </span>
            {userData.carbonFootprint.current < userData.carbonFootprint.countryAverage ? (
              <ArrowDown className="h-4 w-4 text-green-600 ml-1" />
            ) : (
              <ArrowUp className="h-4 w-4 text-red-600 ml-1" />
            )}
            <span className="text-gray-500 text-sm ml-1">your footprint</span>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Breakdown by category */}
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h2 className="text-xl font-semibold mb-6">Breakdown by Category</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value} tons CO₂/year`, "Emission"]} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly trend */}
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h2 className="text-xl font-semibold mb-6">Monthly Trend</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={userData.monthlyTrend} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value} tons CO₂/year`, "Emission"]} />
                <Bar dataKey="emission" fill="#16a34a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Category comparison */}
      <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
        <h2 className="text-xl font-semibold mb-6">Your Emissions vs. Average</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={userData.breakdown} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip formatter={(value) => [`${value} tons CO₂/year`, "Emission"]} />
              <Legend />
              <Bar dataKey="value" name="Your Emission" fill="#16a34a" />
              <Bar dataKey="average" name="Average" fill="#94a3b8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-white p-6 rounded-xl border border-gray-200">
        <h2 className="text-xl font-semibold mb-6">Recommendations to Reduce Your Footprint</h2>
        <div className="space-y-6">
          {userData.recommendations.map((recommendation, index) => (
            <div key={index} className="border-l-4 border-emerald-500 pl-4 py-1">
              <div className="flex items-center mb-2">
                <span
                  className={`inline-flex items-center justify-center rounded-full p-1 mr-2 ${
                    recommendation.impact === "high"
                      ? "bg-red-100 text-red-600"
                      : recommendation.impact === "medium"
                        ? "bg-yellow-100 text-yellow-600"
                        : "bg-blue-100 text-blue-600"
                  }`}
                >
                  {recommendation.impact === "high" ? (
                    <AlertTriangle className="h-4 w-4" />
                  ) : recommendation.impact === "medium" ? (
                    <Info className="h-4 w-4" />
                  ) : (
                    <Leaf className="h-4 w-4" />
                  )}
                </span>
                <h3 className="font-semibold">{recommendation.title}</h3>
                <span className="ml-2 text-xs px-2 py-1 bg-gray-100 rounded-full text-gray-600">
                  {recommendation.category}
                </span>
              </div>
              <p className="text-gray-600 ml-7">{recommendation.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
