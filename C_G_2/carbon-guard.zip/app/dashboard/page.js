"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { BarChart3, FileInput, ArrowRight, Leaf, TrendingDown, AlertTriangle } from "lucide-react"
import { getLatestCarbonData } from "../api/carbon"

export default function Dashboard() {
  const [userData, setUserData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getLatestCarbonData()

        // Transform data for UI
        const transformedData = {
          name: data.latestData?.user?.name || "User",
          carbonFootprint: {
            current: data.latestData?.carbonEmission || 0,
            previous: data.previousData?.carbonEmission || 0,
            change: data.changePercentage || 0,
            globalAverage: 16.3, // Static value for now
            countryAverage: 15.7, // Static value for now
          },
          lastSubmission: data.latestData?.date || null,
          insights: data.insights?.breakdown || [],
          recommendations: data.insights?.recommendations || [],
        }

        setUserData(transformedData)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load dashboard data. Please try again later.")

        // Fallback to mock data if API fails
        setUserData({
          name: "User",
          carbonFootprint: {
            current: 12.5,
            previous: 14.2,
            change: -12,
          },
          lastSubmission: new Date().toISOString(),
          insights: [
            { category: "Transport", value: 5.2, percentage: 42 },
            { category: "Home Energy", value: 3.8, percentage: 30 },
            { category: "Food", value: 2.1, percentage: 17 },
            { category: "Consumption", value: 1.4, percentage: 11 },
          ],
          recommendations: [
            {
              category: "Transport",
              title: "Reduce car usage",
              description: "Try using public transportation, biking, or walking for short trips.",
              impact: "high",
            },
            {
              category: "Home Energy",
              title: "Switch to LED lighting",
              description: "Replace all incandescent bulbs with energy-efficient LED alternatives.",
              impact: "medium",
            },
            {
              category: "Food",
              title: "Reduce meat consumption",
              description: "Try incorporating more plant-based meals into your diet each week.",
              impact: "high",
            },
            {
              category: "Consumption",
              title: "Buy fewer new clothes",
              description: "Consider second-hand shopping or extending the life of your current wardrobe.",
              impact: "medium",
            },
          ],
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">{error}</div>
        <Link
          href="/dashboard/carbon-form"
          className="bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-500 inline-flex items-center"
        >
          <FileInput className="h-4 w-4 mr-2" />
          Submit Your First Carbon Data
        </Link>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Welcome back, {userData.name}</h1>
        <p className="text-gray-600">Here's an overview of your carbon footprint</p>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <Link
          href="/dashboard/carbon-form"
          className="bg-white p-6 rounded-xl border border-gray-200 hover:border-emerald-500 transition-colors flex items-center"
        >
          <div className="bg-emerald-100 p-3 rounded-full mr-4">
            <FileInput className="h-6 w-6 text-emerald-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-lg">Update Your Data</h3>
            <p className="text-gray-600 text-sm">
              {userData.lastSubmission
                ? `Last updated on ${new Date(userData.lastSubmission).toLocaleDateString()}`
                : "Submit your first carbon footprint data"}
            </p>
          </div>
          <ArrowRight className="h-5 w-5 text-gray-400" />
        </Link>

        <Link
          href="/dashboard/insights"
          className="bg-white p-6 rounded-xl border border-gray-200 hover:border-emerald-500 transition-colors flex items-center"
        >
          <div className="bg-emerald-100 p-3 rounded-full mr-4">
            <BarChart3 className="h-6 w-6 text-emerald-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-lg">View Detailed Insights</h3>
            <p className="text-gray-600 text-sm">Analyze your carbon footprint in depth</p>
          </div>
          <ArrowRight className="h-5 w-5 text-gray-400" />
        </Link>
      </div>

      {/* Carbon footprint overview */}
      <div className="bg-white p-6 rounded-xl border border-gray-200 mb-8">
        <h2 className="text-xl font-semibold mb-4">Carbon Footprint Overview</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Current Footprint</p>
            <div className="flex items-end">
              <span className="text-3xl font-bold">{userData.carbonFootprint.current}</span>
              <span className="text-gray-500 ml-1 mb-1">tons CO₂/year</span>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Previous Period</p>
            <div className="flex items-end">
              <span className="text-3xl font-bold">{userData.carbonFootprint.previous}</span>
              <span className="text-gray-500 ml-1 mb-1">tons CO₂/year</span>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Change</p>
            <div className="flex items-center">
              <span
                className={`text-3xl font-bold ${userData.carbonFootprint.change < 0 ? "text-green-600" : "text-red-600"}`}
              >
                {userData.carbonFootprint.change}%
              </span>
              {userData.carbonFootprint.change < 0 ? (
                <TrendingDown className="h-5 w-5 text-green-600 ml-2" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-600 ml-2" />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Breakdown and recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Breakdown by category */}
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Breakdown by Category</h2>
          <div className="space-y-4">
            {userData.insights.map((item, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">{item.name || item.category}</span>
                  <span className="text-sm text-gray-500">
                    {item.value} tons (
                    {item.percentage || Math.round((item.value / userData.carbonFootprint.current) * 100)}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-emerald-600 h-2.5 rounded-full"
                    style={{
                      width: `${item.percentage || Math.round((item.value / userData.carbonFootprint.current) * 100)}%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Recommendations</h2>
          <ul className="space-y-3">
            {userData.recommendations.map((recommendation, index) => (
              <li key={index} className="flex items-start">
                <Leaf className="h-5 w-5 text-emerald-500 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{recommendation.description || recommendation}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
