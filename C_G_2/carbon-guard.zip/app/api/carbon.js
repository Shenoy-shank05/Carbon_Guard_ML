import axios from "axios"
import { setAuthToken } from "./auth"

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5001/api"

// Submit carbon footprint data
export const submitCarbonData = async (formData) => {
  try {
    const token = localStorage.getItem("token")
    setAuthToken(token)

    const response = await axios.post(`${API_URL}/carbon-data`, formData)
    return response.data
  } catch (error) {
    throw error.response?.data || { message: "Server error" }
  }
}

// Get all carbon footprint data for user
export const getCarbonData = async () => {
  try {
    const token = localStorage.getItem("token")
    setAuthToken(token)

    const response = await axios.get(`${API_URL}/carbon-data`)
    return response.data
  } catch (error) {
    throw error.response?.data || { message: "Server error" }
  }
}

// Get latest carbon footprint data with insights
export const getLatestCarbonData = async () => {
  try {
    const token = localStorage.getItem("token")
    setAuthToken(token)

    const response = await axios.get(`${API_URL}/carbon-data/latest`)
    return response.data
  } catch (error) {
    throw error.response?.data || { message: "Server error" }
  }
}
