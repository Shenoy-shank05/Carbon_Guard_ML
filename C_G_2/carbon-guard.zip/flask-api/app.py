from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pandas as pd
import pickle
import os
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

app = Flask(__name__)
CORS(app)

# Load the model if it exists, otherwise train a new one
model_path = 'carbon_emission_model.pkl'
if os.path.exists(model_path):
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    print("Model loaded successfully")
else:
    # We'll create a simple model with dummy data since we don't have real data
    # In a real application, you would train this with actual data
    print("Creating a new model with dummy data")
    
    # Generate dummy data
    np.random.seed(42)
    n_samples = 1000
    
    # Features that would come from the form
    body_types = ['Slim', 'Average', 'Athletic', 'Overweight']
    sexes = ['Male', 'Female', 'Other']
    diets = ['Vegan', 'Vegetarian', 'Pescatarian', 'Omnivore', 'Heavy Meat Eater']
    shower_frequencies = ['Daily', 'Every other day', 'Twice a week', 'Once a week']
    heating_sources = ['Electricity', 'Natural Gas', 'Oil', 'Wood', 'Coal', 'None']
    transport_methods = ['Walking/Cycling', 'Public Transport', 'Car', 'Motorcycle']
    vehicle_types = ['None', 'Electric', 'Hybrid', 'Gasoline', 'Diesel']
    social_activities = ['Rarely', 'Monthly', 'Weekly', 'Multiple times per week']
    air_travel_frequencies = ['Never', 'Once a year', '2-3 times a year', 'Monthly', 'Weekly']
    waste_bag_sizes = ['Small', 'Medium', 'Large']
    energy_efficiency = ['Yes', 'No']
    
    # Generate random categorical data
    data = {
        'bodyType': np.random.choice(body_types, n_samples),
        'sex': np.random.choice(sexes, n_samples),
        'diet': np.random.choice(diets, n_samples),
        'howOftenShower': np.random.choice(shower_frequencies, n_samples),
        'heatingEnergySource': np.random.choice(heating_sources, n_samples),
        'transport': np.random.choice(transport_methods, n_samples),
        'vehicleType': np.random.choice(vehicle_types, n_samples),
        'socialActivity': np.random.choice(social_activities, n_samples),
        'frequencyOfTravelingByAir': np.random.choice(air_travel_frequencies, n_samples),
        'wasteBagSize': np.random.choice(waste_bag_sizes, n_samples),
        'energyEfficiency': np.random.choice(energy_efficiency, n_samples),
        
        # Generate random numerical data
        'monthlyGroceryBill': np.random.uniform(100, 1000, n_samples),
        'vehicleMonthlyDistanceKm': np.random.uniform(0, 2000, n_samples),
        'wasteBagWeeklyCount': np.random.uniform(1, 10, n_samples),
        'howLongTvPcDailyHour': np.random.uniform(0, 12, n_samples),
        'howManyNewClothesMonthly': np.random.uniform(0, 20, n_samples),
        'howLongInternetDailyHour': np.random.uniform(0, 12, n_samples),
    }
    
    # Create a DataFrame
    df = pd.DataFrame(data)
    
    # Generate target variable (carbon emission) based on features
    # This is a simplified model for demonstration
    carbon_emission = np.zeros(n_samples)
    
    # Diet impact
    diet_impact = {
        'Vegan': 1.0,
        'Vegetarian': 1.5,
        'Pescatarian': 2.0,
        'Omnivore': 3.0,
        'Heavy Meat Eater': 4.5
    }
    for diet, impact in diet_impact.items():
        carbon_emission[df['diet'] == diet] += impact
    
    # Transport impact
    transport_impact = {
        'Walking/Cycling': 0.5,
        'Public Transport': 2.0,
        'Motorcycle': 3.5,
        'Car': 5.0
    }
    for transport, impact in transport_impact.items():
        carbon_emission[df['transport'] == transport] += impact
    
    # Vehicle type impact
    vehicle_impact = {
        'None': 0.0,
        'Electric': 1.0,
        'Hybrid': 2.0,
        'Gasoline': 4.0,
        'Diesel': 4.5
    }
    for vehicle, impact in vehicle_impact.items():
        carbon_emission[df['vehicleType'] == vehicle] += impact
    
    # Heating impact
    heating_impact = {
        'None': 0.0,
        'Electricity': 2.0,
        'Natural Gas': 3.0,
        'Oil': 4.0,
        'Wood': 3.5,
        'Coal': 5.0
    }
    for heating, impact in heating_impact.items():
        carbon_emission[df['heatingEnergySource'] == heating] += impact
    
    # Add impact from numerical features
    carbon_emission += df['monthlyGroceryBill'] * 0.002  # More grocery spending = more carbon
    carbon_emission += df['vehicleMonthlyDistanceKm'] * 0.001  # More driving = more carbon
    carbon_emission += df['wasteBagWeeklyCount'] * 0.2  # More waste = more carbon
    carbon_emission += df['howLongTvPcDailyHour'] * 0.1  # More screen time = more carbon
    carbon_emission += df['howManyNewClothesMonthly'] * 0.15  # More new clothes = more carbon
    
    # Add some noise
    carbon_emission += np.random.normal(0, 0.5, n_samples)
    
    # Ensure all values are positive
    carbon_emission = np.maximum(carbon_emission, 1.0)
    
    # Add to DataFrame
    df['carbonEmission'] = carbon_emission
    
    # Define categorical and numerical features
    categorical_features = [
        'bodyType', 'sex', 'diet', 'howOftenShower', 'heatingEnergySource',
        'transport', 'vehicleType', 'socialActivity', 'frequencyOfTravelingByAir',
        'wasteBagSize', 'energyEfficiency'
    ]
    
    numerical_features = [
        'monthlyGroceryBill', 'vehicleMonthlyDistanceKm', 'wasteBagWeeklyCount',
        'howLongTvPcDailyHour', 'howManyNewClothesMonthly', 'howLongInternetDailyHour'
    ]
    
    # Create preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ])
    
    # Create and train the model
    model = Pipeline([
        ('preprocessor', preprocessor),
        ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))
    ])
    
    # Train the model
    X = df.drop('carbonEmission', axis=1)
    y = df['carbonEmission']
    model.fit(X, y)
    
    # Save the model
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    print("Model trained and saved")

# Function to preprocess input data
def preprocess_input(data):
    # Convert input data to DataFrame
    input_df = pd.DataFrame([data])
    
    # Handle missing values
    for col in input_df.columns:
        if col not in data:
            if col in ['monthlyGroceryBill', 'vehicleMonthlyDistanceKm', 'wasteBagWeeklyCount',
                      'howLongTvPcDailyHour', 'howManyNewClothesMonthly', 'howLongInternetDailyHour']:
                input_df[col] = 0
            else:
                input_df[col] = 'None'
    
    return input_df

# Function to generate insights based on prediction
def generate_insights(data, prediction):
    insights = {
        'prediction': prediction,
        'breakdown': calculate_breakdown(data),
        'recommendations': generate_recommendations(data)
    }
    return insights

# Function to calculate breakdown of carbon emission by category
def calculate_breakdown(data):
    # This is a simplified calculation for demonstration
    # In a real application, you would use a more sophisticated model
    
    transport_emission = 0
    if data.get('transport') == 'Car':
        transport_emission = 5.2
    elif data.get('transport') == 'Public Transport':
        transport_emission = 3.1
    elif data.get('transport') == 'Motorcycle':
        transport_emission = 4.0
    else:
        transport_emission = 2.0
    
    energy_emission = 0
    if data.get('heatingEnergySource') == 'Coal':
        energy_emission = 4.8
    elif data.get('heatingEnergySource') == 'Natural Gas':
        energy_emission = 3.8
    elif data.get('heatingEnergySource') == 'Electricity':
        energy_emission = 3.2
    else:
        energy_emission = 3.5
    
    food_emission = 0
    if data.get('diet') == 'Vegan':
        food_emission = 1.2
    elif data.get('diet') == 'Vegetarian':
        food_emission = 1.5
    elif data.get('diet') == 'Omnivore':
        food_emission = 2.1
    elif data.get('diet') == 'Heavy Meat Eater':
        food_emission = 3.5
    else:
        food_emission = 2.1
    
    consumption_emission = 0
    if data.get('howManyNewClothesMonthly', 0) > 5:
        consumption_emission = 2.2
    elif data.get('howManyNewClothesMonthly', 0) > 2:
        consumption_emission = 1.6
    else:
        consumption_emission = 1.4
    
    waste_emission = 0
    if data.get('wasteBagWeeklyCount', 0) > 3:
        waste_emission = 1.2
    elif data.get('wasteBagWeeklyCount', 0) > 1:
        waste_emission = 0.8
    else:
        waste_emission = 0.6
    
    return [
        {'name': 'Transport', 'value': transport_emission, 'average': 4.8},
        {'name': 'Home Energy', 'value': energy_emission, 'average': 4.2},
        {'name': 'Food', 'value': food_emission, 'average': 2.8},
        {'name': 'Consumption', 'value': consumption_emission, 'average': 1.9},
        {'name': 'Waste', 'value': waste_emission, 'average': 1.0}
    ]

# Function to generate recommendations based on user data
def generate_  'average': 1.0}
    ]

# Function to generate recommendations based on user data
def generate_recommendations(data):
    recommendations = []
    
    # Transport recommendations
    if data.get('transport') == 'Car':
        recommendations.append({
            'category': 'Transport',
            'title': 'Reduce car usage',
            'description': 'Try using public transportation, biking, or walking for short trips.',
            'impact': 'high'
        })
    elif data.get('vehicleType') == 'Gasoline' or data.get('vehicleType') == 'Diesel':
        recommendations.append({
            'category': 'Transport',
            'title': 'Consider a more fuel-efficient vehicle',
            'description': 'When it\'s time to replace your vehicle, consider an electric or hybrid option.',
            'impact': 'high'
        })
    
    # Energy recommendations
    if data.get('heatingEnergySource') in ['Coal', 'Oil']:
        recommendations.append({
            'category': 'Home Energy',
            'title': 'Switch to cleaner energy',
            'description': 'Consider switching to natural gas or electricity for heating.',
            'impact': 'high'
        })
    
    if data.get('energyEfficiency') == 'No':
        recommendations.append({
            'category': 'Home Energy',
            'title': 'Use energy-efficient appliances',
            'description': 'Replace old appliances with energy-efficient models and use LED lighting.',
            'impact': 'medium'
        })
    
    # Diet recommendations
    if data.get('diet') in ['Heavy Meat Eater', 'Omnivore']:
        recommendations.append({
            'category': 'Food',
            'title': 'Reduce meat consumption',
            'description': 'Try incorporating more plant-based meals into your diet each week.',
            'impact': 'high'
        })
    
    # Consumption recommendations
    if data.get('howManyNewClothesMonthly', 0) > 3:
        recommendations.append({
            'category': 'Consumption',
            'title': 'Buy fewer new clothes',
            'description': 'Consider second-hand shopping or extending the life of your current wardrobe.',
            'impact': 'medium'
        })
    
    # Waste recommendations
    if 'None' in data.get('recycling', []) or not data.get('recycling'):
        recommendations.append({
            'category': 'Waste',
            'title': 'Start recycling',
            'description': 'Begin separating recyclables from your regular trash.',
            'impact': 'medium'
        })
    elif len(data.get('recycling', [])) < 3:
        recommendations.append({
            'category': 'Waste',
            'title': 'Improve recycling habits',
            'description': 'Expand your recycling to include more materials like glass, metal, and electronics.',
            'impact': 'low'
        })
    
    # If we don't have enough recommendations, add some general ones
    if len(recommendations) < 3:
        recommendations.append({
            'category': 'Home Energy',
            'title': 'Reduce standby power consumption',
            'description': 'Unplug electronics when not in use or use power strips with switches.',
            'impact': 'low'
        })
        
        recommendations.append({
            'category': 'Consumption',
            'title': 'Choose products with less packaging',
            'description': 'Opt for products with minimal or recyclable packaging.',
            'impact': 'low'
        })
    
    return recommendations[:5]  # Return top 5 recommendations

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from request
        data = request.json
        
        # Preprocess input data
        input_df = preprocess_input(data)
        
        # Make prediction
        prediction = model.predict(input_df)[0]
        
        # Generate insights
        insights = generate_insights(data, float(prediction))
        
        return jsonify(insights)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/insights', methods=['POST'])
def get_insights():
    try:
        # Get data from request
        data = request.json.get('carbonData', {})
        
        # Generate insights
        insights = generate_insights(data, data.get('carbonEmission', 0))
        
        return jsonify({'insights': insights})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
